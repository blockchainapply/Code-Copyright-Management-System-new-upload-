package code_handle;
import java.util.Scanner;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import org.antlr.v4.runtime.CharStreams;

import java.io.* ; 

public class Code2 {
	
	public static void main(String[] args) throws Exception{
	   
		Scanner sc = new Scanner(System.in);
		String words = sc.nextLine();
		
		ANTLRInputStream input = new ANTLRInputStream(words);
		CharStream cs = CharStreams.fromFileName("compat.txt");
		ParseTreeWalker walker = new ParseTreeWalker();
		Python3Lexer lexer = new Python3Lexer(cs);
		CommonTokenStream tokens = new CommonTokenStream(lexer);
		Python3Parser parse = new Python3Parser(tokens);
		
		ParseTree tree = parse.single_input();
		System.out.println("tree:");
		System.out.println(tree.toStringTree(parse));
		
		Java8Loader listener = new Java8Loader();


	    walker.walk(listener,tree);
	    System.out.println();
	    
	    File file = new File(root+File.separator+"java.txt" );
	    BufferedWriter buffw = null;
		try {
			buffw = new BufferedWriter( new FileWriter(file) );
			for(int i = 0; i < listener.list.size(); i++ ) {
				buffw.write( listener.list.get(i)+" " );
				buffw.newLine();
				}
			buffw.close();
			} catch (IOException e) {
				e.printStackTrace();}

	}
 
}



