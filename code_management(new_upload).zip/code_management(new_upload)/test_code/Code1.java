package code_handle;

import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

import java.io.* ; 

public class AST {
	
	public static void main(String[] args) throws Exception{

		String root = System.getProperty("user.dir");
		CharStream cs = CharStreams.fromFileName( root+File.separator+"Code1.java");		
		JavaLexer lexer = new JavaLexer(cs);
		CommonTokenStream tokens = new CommonTokenStream(lexer);	
		JavaParser parser = new JavaParser(tokens);	
		ParseTree tree = parser.compilationUnit();
		
		System.out.println("tree:");
		System.out.println(tree.toStringTree(parser));
		
		listenerJava listener = new listenerJava();
	    ParseTreeWalker walker = new ParseTreeWalker();
	    walker.walk(listener,tree);
	    
	    File file = new File(root+File.separator+"Code1_tokens_java.txt" );
	    BufferedWriter bw = null;
		try {
			bw = new BufferedWriter( new FileWriter(file) );
			for(int i = 0; i < listener.list.size(); i++ ) {
				bw.write( listener.list.get(i)+" " );
				bw.newLine();
				}
			bw.close();
			} catch (IOException e) {
				e.printStackTrace();}

	}
 
}



